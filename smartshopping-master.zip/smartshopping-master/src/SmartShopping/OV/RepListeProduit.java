package SmartShopping.OV;

public class RepListeProduit extends OVRep{
	
	OVListeProduit lp;
	
	public RepListeProduit(){
		
	}
}
