package com.example.sshopping;

public class REQUEST_CODE {
	public static int GET_POINT_ON_MAP = 0;
	public static int MODIFIE_POINT_ON_MAP = 1;
}
