package com.example.sshopping.http;

import org.json.JSONObject;

public interface OnDataReturnListener {
	public void OnDataReturn(JSONObject jobj);
}
