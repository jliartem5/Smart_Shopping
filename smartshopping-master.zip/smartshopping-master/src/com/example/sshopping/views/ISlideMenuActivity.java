package com.example.sshopping.views;

public interface ISlideMenuActivity {
	public void closeSlideMenu();
	public void openSlideMenu();
}
