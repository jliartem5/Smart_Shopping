package com.example.sshopping.PlaceSelect;

import SmartShopping.ShortestPath.Vertex;

public interface OnMarkerClickListener {
	public void OnMarkerClick(Vertex v, int[] position);
}
